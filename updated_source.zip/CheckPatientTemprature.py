# !/usr/bin/env python
import sys
import os
sys.path.append(os.getcwd()[:os.getcwd().index('com')])
import Adafruit_DHT
import time

class CheckPatientTemprature:

    def __init__(self):
        print('init')
    pass

    def get_patient_temprature(self):
        myfile = open('PatientDetails.txt', 'w')
        try:
            print('[ get_patient_temprature() ]')
            DHT_SENSOR = Adafruit_DHT.DHT11
            DHT_PIN = 4
            while True:
                humid, temperature = Adafruit_DHT.read(DHT_SENSOR, DHT_PIN)
                if humid is not None and temperature is not None:
                    # print("Temp={0:0.1f}C Humid={1:0.1f}%".format(temperature, humid))
                    tempCelsius = "{0: 0.1f}".format(temperature, humid )
                    tempCelsius = str(int(float(tempCelsius)) + 3)
                    # print(tempCelsius)
                    tempFahrenheit = (int(float(tempCelsius)) * 9/5) + 32
                    print('Patient Temprature is :'+str(tempFahrenheit))
                    # print('Patient Temprature is :' + str(temperature))
                    myfile.write("Patient Name:ABC#Age:25#Temprature:"+str(tempFahrenheit)+"\n")
                else:
                    print("Sensor failure. Check wiring.");
                    print(Adafruit_DHT.read(DHT_SENSOR, DHT_PIN))
                time.sleep(60);
            pass
            myfile.close()
        except Exception as ex:
            print('Error :'+str(ex))
            myfile.close()


def main():
    print('[ CheckPatientTemprature# main method ]')
    check_patient_temprature = CheckPatientTemprature()
    check_patient_temprature.get_patient_temprature()

if __name__ == '__main__':
    main()
